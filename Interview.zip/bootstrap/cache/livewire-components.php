<?php return array (
  'product-component' => 'App\\Http\\Livewire\\ProductComponent',
);